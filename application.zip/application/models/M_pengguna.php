<?php
class M_pengguna extends CI_Model
{
  public function saldo($id)
  {
    return $this->db->get_where('t_saldo', ['id_kios' => $id, 'status_penggunaan' => '1'])->row_array();
  }

  public function transaksi($id)
  {
    return $this->db->get_where('t_transaksi', ['id_kios' => $id])->result_array();
  }
  public function transaksi_admin()
  {
    return $this->db->get('t_transaksi')->result_array();
  }
}
