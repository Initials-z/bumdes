<?php

class M_admin extends CI_Model
{
  public function tampil()
  {
    return $this->db->get('t_admin')->result_array();
  }

  public function input($gambar)
  {
    $data = [
      'nama_admin' => htmlspecialchars($this->input->post('nama_admin')),
      'email_admin' => htmlspecialchars($this->input->post('email_admin')),
      'no_hp' => htmlspecialchars($this->input->post('no_hp')),
      'alamat' => htmlspecialchars($this->input->post('alamat')),
      'tempat_lahir' => htmlspecialchars($this->input->post('tempat_lahir')),
      'tanggal_lahir' => $this->input->post('tanggal_lahir'),
      'foto' => $gambar
    ];

    // var_dump($data);

    $ps = 12345;
    $akun = [
      'username' => htmlspecialchars($this->input->post('email_admin')),
      'password' => password_hash($ps, PASSWORD_DEFAULT),
      'akses' => '0',
      'waktu_input' => time()
    ];

    $this->db->set('id_admin', 'UUID()', FALSE);
    $this->db->insert('t_admin', $data);

    $this->db->set('id_user', 'UUID()', FALSE);
    $this->db->insert('t_user', $akun);
  }

  public function hapus($id)
  {
    $pilih = $this->db->get_where('t_admin', ['id_admin' => $id])->row_array();

    if ($pilih['foto'] == 'user.png') {
      $ambil = $this->db->get_where('t_user', ['username' => $pilih['email_admin']])->row_array();
      $this->db->where('id_user', $ambil['id_user']);
      $this->db->delete('t_user');

      $this->db->where('id_admin', $id);
      $this->db->delete('t_admin');
    } else {
      $ambil = $this->db->get_where('t_user', ['username' => $pilih['email_admin']])->row_array();

      $lokasi = './gambar/admin/' . $pilih['foto'];
      unlink($lokasi);
      $this->db->where('id_user', $ambil['id_user']);
      $this->db->delete('t_user');

      $this->db->where('id_admin', $id);
      $this->db->delete('t_admin');
    }
  }

  public function tampil_profile_admin($id)
  {
    return $this->db->get_where('t_admin', ['id_admin' => $id])->row_array();
  }

  public function edit_proses($id, $gambar)
  {
    $data = [
      'nama_admin' => htmlspecialchars($this->input->post('nama_admin')),
      'email_admin' => htmlspecialchars($this->input->post('email_admin')),
      'no_hp' => htmlspecialchars($this->input->post('no_hp')),
      'alamat' => htmlspecialchars($this->input->post('alamat')),
      'tempat_lahir' => htmlspecialchars($this->input->post('tempat_lahir')),
      'tanggal_lahir' => $this->input->post('tanggal_lahir'),
      'foto' => $gambar
    ];

    $this->db->where('id_admin', $id);
    $this->db->update('t_admin', $data);
  }

  public function jumlah_admin()
  {
    // count data as t_admin
    $this->db->select('count(*) as jumlah_admin');
    $this->db->from('t_admin');
    $query = $this->db->get();
    return $query->row_array();
  }
}
