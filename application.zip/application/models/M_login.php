<?php

class M_login extends CI_Model
{
  
}

?>