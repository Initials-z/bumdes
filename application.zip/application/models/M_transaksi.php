<?php

class M_transaksi extends CI_Model
{
  public function harga()
  {
    return $this->db->get('t_harga_jual')->result_array();
  }
  public function jumlah_transaksi()
  {
    // count data transaksi on this day
    $this->db->where('tanggal', date('Y-m-d'));
    $this->db->from('t_transaksi');
    return $this->db->count_all_results();
  }
  public function jumlah_transaksi_kios($id_kios)
  {
    // count data transaksi on this day
    $this->db->where('id_kios', $id_kios);
    $this->db->where('tanggal', date('Y-m-d'));
    $this->db->from('t_transaksi');
    return $this->db->count_all_results();
  }

  public function harga_jual()
  {
    $harga = $this->input->post('harga');
    $kode = $this->input->post('buyer_sku_code');
    $jumlah = count($this->input->post('buyer_sku_code'));
    for ($i = 0; $i < $jumlah; $i++) {
      $cek = $this->db->get_where('t_harga_jual', ['buyer_sku_code' => $kode[$i]])->row_array();
      // var_dump($cek);
      // die;
      if (isset($cek)) {
        $this->db->where('buyer_sku_code', $kode[$i]);
        $this->db->update('t_harga_jual', ['harga' => $harga[$i]]);
      } else {
        $data = array(
          'buyer_sku_code' => htmlspecialchars($kode[$i]),
          'harga' => htmlspecialchars($harga[$i])
        );

        $this->db->set('id_harga_jual', 'UUID()', FALSE);
        $this->db->insert('t_harga_jual', $data);
      }
    }
  }
}
