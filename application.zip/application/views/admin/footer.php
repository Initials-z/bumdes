<script src="<?= base_url('data_tabel/') ?>jquery-3.5.1.js"></script>
<script src="<?= base_url() ?>assets/js/vendor-all.min.js"></script>
<script src="<?= base_url() ?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/pcoded.min.js"></script>
<!-- Apex Chart -->
<script src="<?= base_url() ?>assets/js/plugins/apexcharts.min.js"></script>
<!-- custom-chart js -->
<script src="<?= base_url() ?>assets/js/pages/dashboard-main.js"></script>
<script src="<?= base_url('data_tabel/') ?>jquery.dataTables.min.js"></script>
<script src="<?= base_url('select2/') ?>js/select2.min.js"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                jQuery('#blah').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imgInp").change(function() {
        readURL(this);
    });

    function reloadpage() {
        location.reload()
    }
</script>
<script>
    $(document).ready(function() {
        $("#myform").submit(function(e) {

            var formObj = $(this);
            var formURL = formObj.attr("action");
            var formData = new FormData(this);
            $.ajax({
                url: formURL,
                type: 'POST',
                data: formData,
                contentType: true,
                cache: false,
                processData: true,
                beforeSend: function() {
                    $("#loading").show(100).html("<div class='spinner-grow text-success' role='status'><span class='sr-only'>Loading...</span></div>");
                },
                success: function(data, textStatus, jqXHR) {
                    $("#result").html(data);
                    $("#loading").hide();
                },
                error: function(jqXHR, textStatus, errorThrown) {}
            });
            e.preventDefault(); //Prevent Default action.
            e.unbind();
        });
        $('.js-example-basic-single').select2();
        $('#example').DataTable();
    });
</script>
<script type="text/javascript">
    var rupiah = document.getElementById('rupiah');
    rupiah.addEventListener('keyup', function(e) {
        // tambahkan 'Rp.' pada saat form di ketik
        // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
        rupiah.value = formatRupiah(this.value, 'Rp. ');
    });
    /* Fungsi formatRupiah */
    function formatRupiah(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
</script>
</body>

</html>