<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->client = new \GuzzleHttp\Client;

    $this->load->model('M_login');
    $this->load->model('M_admin');
    $this->load->model('M_mobilepulsa');
    $this->load->model('M_kios');
    $this->load->model('M_transaksi');
    $this->load->model('M_pengguna');

    $this->load->library('form_validation');
    if (!$this->session->userdata('username')) {
      redirect('Welcome/not_found');
    } elseif ($this->session->userdata('akses') == '1') {
      redirect('Welcome/not_found');
    }
  }

  public function index()
  {
    $data1 = $this->M_mobilepulsa->saldo();
    $data = [
      'judul' => 'Halaman Admin',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_mobilepulsa->saldo(),
      'jumlah' => $this->M_kios->jumlah_kios(),
      'jumlah_adm' => $this->M_admin->jumlah_admin(),
      'transaksi' => $this->M_transaksi->jumlah_transaksi()
    ];
    // var_dump($data1);
    // die;

    $this->load->view('admin/head', $data);
    $this->load->view('admin/home', $data);
    $this->load->view('admin/footer');
  }

  public function admin_tabel()
  {
    $data = [
      'judul' => 'Tabel Data Admin',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'tampil' => $this->M_admin->tampil()
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_admin/tabel_admin', $data);
    $this->load->view('admin/footer');
  }

  public function form_input()
  {
    $data = [
      'judul' => 'Form Input Data Admin',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'kembali' => 'tabel_admin',
    ];
    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_admin/form_input_admin', $data);
    $this->load->view('admin/footer');
  }

  public function proses_input()
  {
    $this->form_validation->set_rules('nama_admin', 'Nama Admin', 'required|trim');
    $this->form_validation->set_rules('email_admin', 'Email Admin', 'required|trim|valid_email|is_unique[t_admin.email_admin]', [
      'is_unique' => 'Email sudah terdaftar!'
    ]);
    $this->form_validation->set_rules('no_hp', 'Nomor Hp', 'required|trim|numeric');
    $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
    $this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');

    if ($this->form_validation->run() == false) {
      $data = [
        'judul' => 'Form Input Data Admin',
        'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
        'kembali' => 'tabel_admin',
      ];
      $this->load->view('admin/head', $data);
      $this->load->view('admin/data_admin/form_input_admin', $data);
      $this->load->view('admin/footer');
    } else {
      $nbar = $this->input->post('nama_admin');
      $tsp = str_replace(" ", "", $nbar);
      $tsp1 = str_replace(".", "", $tsp);
      $tsp2 = str_replace(",", "", $tsp1);

      $file_name                  = $tsp2 . '-' . time();
      $config['upload_path']      = './gambar/admin/';
      $config['allowed_types']    = 'png|jpg|jpeg';
      $config['encrypt_name']     = FALSE;
      $config['file_name']        = $file_name;
      $config['max_size']         = 100000;

      $cek = $this->load->library('upload', $config);

      if ($this->upload->do_upload('foto_admin')) {
        $data = array('upload_data' => $this->upload->data());
        $gambar = $data['upload_data']['file_name'];
        $this->M_admin->input($gambar);
      } else {
        $gambar = 'user.png';
        $this->M_admin->input($gambar);
      }

      $this->session->set_flashdata('berhasil', '<div class="alert alert-success" role="alert">Data berhasil ditambahkan!</div>');
      redirect('Admin/admin_tabel');
    }
  }

  public function tampil_admin($id)
  {
    $data = [
      'judul' => 'Data Profile Admin',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'tampil' => $this->M_admin->tampil_profile_admin($id),
      'kembali' => 'Admin/admin_tabel',
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_admin/tampil_admin', $data);
    $this->load->view('admin/footer');
  }

  public function hapus_admin($id)
  {
    $this->M_admin->hapus($id);
    $this->session->set_flashdata('terhapus', '<div class="alert alert-success" role="alert">Data berhasil dihapus!</div>');
    redirect('Admin/admin_tabel');
  }

  public function proses_admin_edit()
  {
    $id = htmlspecialchars($this->input->post('id_admin'));
    $nbar = $this->input->post('nama_admin');
    $tsp = str_replace(" ", "", $nbar);
    $tsp1 = str_replace(".", "", $tsp);
    $tsp2 = str_replace(",", "", $tsp1);

    $file_name                  = $tsp2 . '-' . time();
    $config['upload_path']      = './gambar/admin/';
    $config['allowed_types']    = 'png|jpg|jpeg';
    $config['encrypt_name']     = FALSE;
    $config['file_name']        = $file_name;
    $config['max_size']         = 100000;

    $cek = $this->load->library('upload', $config);
    $pilih = $this->db->get_where('t_admin', ['id_admin' => $id])->row_array();

    if ($this->upload->do_upload('foto_admin')) {
      $lokasi = './gambar/admin/' . $pilih['foto'];
      unlink($lokasi);

      $data = array('upload_data' => $this->upload->data());
      $gambar = $data['upload_data']['file_name'];
      $this->M_admin->edit_proses($id, $gambar);
    } else {
      $gambar = $pilih['foto'];
      $this->M_admin->edit_proses($id, $gambar);
    }

    $this->session->set_flashdata('berubah', '<div class="alert alert-success" role="alert">Data berhasil ditambahkan!</div>');
    redirect('Admin/tampil_admin/' . $id);
  }

  public function limit()
  {
    $data = [
      'judul' => 'Data Saldo Pulsa',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'kios' => $this->M_kios->tampil(),
      'limit' => $this->M_kios->limit(),
      'saldo' => $this->M_mobilepulsa->saldo(),
      't_saldo' => $this->M_mobilepulsa->total_saldo(),
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_limit/tabel_limit', $data);
    $this->load->view('admin/footer');
  }

  public function list()
  {
    $cek_list = $this->M_mobilepulsa->_list_harga('TELKOMSEL')->data;
    // var_dump($cek_list);
    // print_r($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Pulsa',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list,
      'harga' => $this->M_transaksi->harga(),
    ];
    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_list/list_harga', $data);
    $this->load->view('admin/footer');
  }

  public function list_paket()
  {
    $cek_list = $this->M_mobilepulsa->_list_harga('data')->data;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Paket Data',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_list/list_paket', $data);
    $this->load->view('admin/footer');
  }

  public function list_pln()
  {
    $cek_list = $this->M_mobilepulsa->_list_harga('pln')->data;
    $data = [
      'judul' => 'Data List PLN',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_list/list_pln', $data);
    $this->load->view('admin/footer');
  }

  public function list_game()
  {
    $cek_list = $this->M_mobilepulsa->_list_harga('game')->data;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Top Up Game',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_list/list_game', $data);
    $this->load->view('admin/footer');
  }

  public function list_money()
  {
    $cek_list = $this->M_mobilepulsa->_list_harga('etoll')->data;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data Saldo E-Money',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_list/list_e-money', $data);
    $this->load->view('admin/footer');
  }

  public function list_internet_pasca()
  {
    $cek_pasca = $this->M_mobilepulsa->list_pasca('INTERNET PASCABAYAR')->data;
    // var_dump($cek_pasca);
    // die;
    $data = [
      'judul' => 'Data Saldo E-Money',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_pasca
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/internet_pasca', $data);
    $this->load->view('admin/footer');
  }
  public function list_multifinance()
  {
    $cek_pasca = $this->M_mobilepulsa->list_pasca('MULTIFINANCE')->data;
    // var_dump($cek_pasca);
    // die;
    $data = [
      'judul' => 'Data Saldo E-Money',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_pasca
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/list_multifinance', $data);
    $this->load->view('admin/footer');
  }

  public function form_tagihan_listrik()
  {
    $data = [
      'judul' => 'Form Tagihan Listrik',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_tagihan/form_tagihan_listrik', $data);
    $this->load->view('admin/footer');
  }

  public function cek_tagihan_listrik()
  {
    $no_kostumer = $this->input->post('custommer_no');
    $ref = $this->random_strings(8);
    $cek_list = $this->M_mobilepulsa->cek_api($no_kostumer, $ref)->data;
    $kode_pelanggan = $cek_list->customer_no;
    $nama_pelanggan = $cek_list->customer_name;
    $tagihan = $cek_list->desc->detail[0]->nilai_tagihan;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data Tagihan Listrik',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_tagihan/tagihan_listrik', $data);
    $this->load->view('admin/footer');
  }

  public function random_strings($length_of_string)
  {
    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

    return substr(str_shuffle($str_result), 0, $length_of_string);
  }

  public function cek_tagihan_pasca()
  {
    $no_kostumer = $this->input->post('custommer_no');
    $kode_produk = $this->input->post('buyer_sku_code');
    $random = $this->random_strings(8);
    $cek_list = $this->M_mobilepulsa->cek_api_pasca($no_kostumer, $random, $kode_produk)->data;
    $kode_pelanggan = $cek_list->customer_no;
    $nama_pelanggan = $cek_list->customer_name;
    $tagihan = $cek_list->desc->detail[0]->nilai_tagihan;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data Tagihan Listrik',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/tagihan', $data);
    $this->load->view('admin/footer');
  }

  public function form_pasca($kode)
  {
    $data = [
      'judul' => 'Data Pascabayar Internet',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'kode_pasca' => $kode
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/form_pasca', $data);
    $this->load->view('admin/footer');
  }

  public function form_multi($kode)
  {
    $data = [
      'judul' => 'Multi Finance',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'kode_pasca' => $kode
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/form_multi', $data);
    $this->load->view('admin/footer');
  }

  public function cek_tagihan_multi()
  {
    $no_kostumer = $this->input->post('custommer_no');
    $kode_produk = $this->input->post('buyer_sku_code');
    $random = $this->random_strings(8);
    $cek_list = $this->M_mobilepulsa->cek_api_pasca($no_kostumer, $random, $kode_produk)->data;
    $kode_pelanggan = $cek_list->customer_no;
    $nama_pelanggan = $cek_list->customer_name;
    // $tagihan = $cek_list->desc->detail[0]->selling_price;
    // var_dump($cek_list);
    // die;
    $data = [
      'judul' => 'Data Tagihan Listrik',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'list' => $cek_list
    ];

    $this->load->view('admin/head', $data);
    $this->load->view('admin/data_pasca/tagihan_pasca', $data);
    $this->load->view('admin/footer');
  }

  public function pos_harga()
  {
    $kembali = htmlspecialchars($this->input->post('redir'));
    // var_dump($this->input->post());
    // die;
    $this->M_transaksi->harga_jual();
    redirect($kembali);
  }
  public function laporan()
  {
    $random = $this->random_strings(8);
    // $status = $this->M_mobilepulsa->cek_status($random)->data;
    $data = [
      'judul' => 'Data Laporan Transaksi Kios',
      'user' => $this->db->get_where('t_admin', ['email_admin' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_mobilepulsa->saldo(),
      'akses' => $this->db->get_where('t_user', ['username' => $this->session->userdata('username')])->row_array(),
      'transaksi' => $this->M_pengguna->transaksi_admin(),
      // 'status' => $status,
    ];
    $this->load->view('Admin/head', $data);
    $this->load->view('Pengguna/transaksi/laporan_transaksi', $data);
    $this->load->view('Admin/footer', $data);
  }
}
