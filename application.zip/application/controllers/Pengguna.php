<?php
class Pengguna extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('M_pengguna');
    $this->load->model('M_transaksi');
    $this->load->model('M_mobilepulsa');
    $this->load->helper('form');

    $this->load->library('form_validation');
    if (!$this->session->userdata('username')) {
      redirect('Welcome/not_found_user');
    } elseif ($this->session->userdata('akses') == 0) {
      redirect('Welcome/not_found_user');
    }
  }

  public function random_strings($length_of_string)
  {
    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

    return substr(str_shuffle($str_result), 0, $length_of_string);
  }

  public function index()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $data = [
      'judul' => 'Dashboard Kios',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'jumlah' => $this->M_pengguna->transaksi($id_kios),
      'transaksi' => $this->M_transaksi->jumlah_transaksi($id_kios),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/home', $data);
    $this->load->view('Pengguna/footer', $data);
  }


  public function laporan()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $random = $this->random_strings(8);
    // $status = $this->M_mobilepulsa->cek_status($random)->data;
    $data = [
      'judul' => 'Dashboard Kios',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'transaksi' => $this->M_pengguna->transaksi($id_kios),
      // 'status' => $status,
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/transaksi/laporan_transaksi', $data);
    $this->load->view('Pengguna/footer', $data);
  }

  public function cek_status($kode, $nomor, $ref_id)
  {
    // $random = $this->random_strings(8);
    $ref = $ref_id;
    $status = $this->M_mobilepulsa->cek_status($ref, $kode, $nomor)->data;
    var_dump($status);
    die;
  }

  public function pulsa()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $cek_list = $this->M_mobilepulsa->_list_harga('TELKOMSEL')->data;
    // $rack_list = $this->suggest->get_rack_details();
    // var_dump($cek_list);
    // json_encode($cek_list);
    // print_r($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Pulsa',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'transaksi' => $this->M_transaksi->jumlah_transaksi($id_kios),
      'list' => $cek_list,
      'harga' => $this->M_transaksi->harga(),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/data_list/list_harga', $data);
    $this->load->view('Pengguna/footer');
  }
  public function paket()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $cek_list = $this->M_mobilepulsa->_list_harga('TELKOMSEL')->data;
    // $rack_list = $this->suggest->get_rack_details();
    // var_dump($cek_list);
    // json_encode($cek_list);
    // print_r($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Pulsa',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'transaksi' => $this->M_transaksi->jumlah_transaksi($id_kios),
      'list' => $cek_list,
      'harga' => $this->M_transaksi->harga(),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/data_list/list_paket', $data);
    $this->load->view('Pengguna/footer');
  }
  public function token()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $cek_list = $this->M_mobilepulsa->_list_harga('PULSA PLN')->data;
    // $rack_list = $this->suggest->get_rack_details();
    // var_dump($cek_list);
    // json_encode($cek_list);
    // print_r($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Pulsa',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'transaksi' => $this->M_transaksi->jumlah_transaksi($id_kios),
      'list' => $cek_list,
      'harga' => $this->M_transaksi->harga(),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/data_list/list_pln', $data);
    $this->load->view('Pengguna/footer');
  }
  public function e_money()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];
    $cek_list = $this->M_mobilepulsa->_list_harga('E-Money')->data;
    // $rack_list = $this->suggest->get_rack_details();
    // var_dump($cek_list);
    // json_encode($cek_list);
    // print_r($cek_list);
    // die;
    $data = [
      'judul' => 'Data List Pulsa',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'transaksi' => $this->M_transaksi->jumlah_transaksi($id_kios),
      'list' => $cek_list,
      'harga' => $this->M_transaksi->harga(),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/data_list/list_e-money', $data);
    $this->load->view('Pengguna/footer');
  }
  public function status_transaksi()
  {
    $id = $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array();
    $id_kios = $id['id_kios'];

    $respon = $this->M_mobilepulsa->cek_status_transaksi()->data;
    // var_dump($this->input->post());
    // die;
    if ($respon->status == "Sukses") {
      $saldo = $this->db->get_where('t_saldo', ['id_kios' => $id_kios])->row_array();
      $p_harga = $this->input->post('harga');
      $harga =  -$saldo['jumlah_saldo'] - $p_harga;

      $untung = $p_harga - $respon->price;

      $this->db->where('id_kios', $id_kios);
      $this->db->update('t_saldo', ['jumlah_saldo' => $harga]);

      $this->db->set('id_transaksi', 'UUID()', FALSE);
      $this->db->insert('t_transaksi', [
        'kode_transaksi' => $this->input->post('kode_transaksi'),
        'deskripsi' => $this->input->post('deskripsi'),
        'kode_produk' => $respon->buyer_sku_code,
        'id_kios' => $id_kios,
        'no_pelanggan' => $respon->customer_no,
        'harga_beli' => $respon->price,
        'harga_jual' => $p_harga,
        'keuntungan' => $untung,
        'tanggal' => date('Y-m-d H:i:s'),
        'ref_id' => $respon->ref_id,
      ]);
    } else {
    }
    $data = [
      'judul' => 'Detail Transaksi',
      'user' => $this->db->get_where('t_kios', ['kode_kios' => $this->session->userdata('username')])->row_array(),
      'saldo' => $this->M_pengguna->saldo($id_kios),
      'respon' => $respon,
      'kode_transaksi' => $this->input->post('kode_transaksi'),
      'deskripsi' => $this->input->post('deskripsi'),
    ];
    $this->load->view('Pengguna/head', $data);
    $this->load->view('Pengguna/transaksi/detail_transaksi', $data);
    $this->load->view('Pengguna/footer');
  }
}
